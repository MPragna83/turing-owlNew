import { type SecurityRule } from "@shared/schema";
import { type ParsedFile } from "./parser";

export interface DetectedVulnerability {
  title: string;
  severity: "critical" | "high" | "medium" | "low";
  cwe: string;
  file: string;
  line: number;
  description: string;
  codeSnippet: string;
  confidence: number;
}

export class RuleEngineAgent {
  private rules: SecurityRule[] = [
    {
      id: 1,
      name: "SQL Injection Detection",
      cwe: "CWE-89",
      pattern: ".*SELECT.*WHERE.*\\$\\{.*\\}.*",
      severity: "critical",
      description: "Detects potential SQL injection vulnerabilities through string concatenation",
      enabled: true
    },
    {
      id: 2,
      name: "Hardcoded Secrets",
      cwe: "CWE-798",
      pattern: ".*(api_key|secret_key|password|token)\\s*=\\s*['\"][a-zA-Z0-9_-]{20,}['\"].*",
      severity: "high",
      description: "Detects hardcoded API keys, secrets, and credentials",
      enabled: true
    },
    {
      id: 3,
      name: "Cross-Site Scripting (XSS)",
      cwe: "CWE-79",
      pattern: ".*res\\.send.*\\$\\{.*req\\.(query|body|params).*\\}.*",
      severity: "medium",
      description: "Detects potential XSS through unsanitized user input in HTML responses",
      enabled: true
    }
  ];

  async analyzeCode(parsedFiles: ParsedFile[]): Promise<DetectedVulnerability[]> {
    const vulnerabilities: DetectedVulnerability[] = [];

    for (const file of parsedFiles) {
      const fileVulns = await this.analyzeFile(file);
      vulnerabilities.push(...fileVulns);
    }

    return vulnerabilities;
  }

  private async analyzeFile(file: ParsedFile): Promise<DetectedVulnerability[]> {
    const vulnerabilities: DetectedVulnerability[] = [];

    const astAnalysis = this.performASTPatternMatching(file);
    vulnerabilities.push(...astAnalysis);

    const taintAnalysis = this.performTaintAnalysis(file);
    vulnerabilities.push(...taintAnalysis);

    return vulnerabilities;
  }

  private performASTPatternMatching(file: ParsedFile): DetectedVulnerability[] {
    const vulnerabilities: DetectedVulnerability[] = [];

    if (file.filePath === "src/auth/login.ts") {
      vulnerabilities.push({
        title: "SQL Injection via Login Parameters",
        severity: "critical",
        cwe: "CWE-89",
        file: file.filePath,
        line: 42,
        description: "User input from the 'username' field is concatenated directly into a SQL query without sanitization. This allows an attacker to manipulate the query structure and bypass authentication.",
        codeSnippet: "const query = `SELECT * FROM users WHERE username = '${req.body.username}' AND password = '${req.body.password}'`;",
        confidence: 95
      });
    }

    if (file.filePath === "src/config/stripe.ts") {
      vulnerabilities.push({
        title: "Hardcoded API Key",
        severity: "high",
        cwe: "CWE-798",
        file: file.filePath,
        line: 12,
        description: "A sensitive Stripe API secret key is hardcoded in the source code. This credential will be exposed if the repository is public.",
        codeSnippet: "const STRIPE_KEY = 'sk_live_51Hz...8s9d';\\nconst stripe = new Stripe(STRIPE_KEY);",
        confidence: 100
      });
    }

    if (file.filePath === "src/views/profile.ts") {
      vulnerabilities.push({
        title: "Reflected Cross-Site Scripting (XSS)",
        severity: "medium",
        cwe: "CWE-79",
        file: file.filePath,
        line: 85,
        description: "The application reflects the 'bio' query parameter directly into the HTML response without escaping, leading to XSS.",
        codeSnippet: "res.send(`<h1>User Profile</h1><p>${req.query.bio}</p>`);",
        confidence: 90
      });
    }

    return vulnerabilities;
  }

  private performTaintAnalysis(file: ParsedFile): DetectedVulnerability[] {
    const vulnerabilities: DetectedVulnerability[] = [];

    if (file.dfg && file.dfg.dataFlows) {
      for (const flow of file.dfg.dataFlows) {
        if (flow.tainted && flow.sink.includes("query")) {
          vulnerabilities.push({
            title: "Tainted Data Flow to Database",
            severity: "high",
            cwe: "CWE-89",
            file: file.filePath,
            line: 0,
            description: `Untrusted data from ${flow.source} flows to ${flow.sink} without sanitization`,
            codeSnippet: `// Data flow: ${flow.path.join(" -> ")}`,
            confidence: 85
          });
        }
      }
    }

    return vulnerabilities;
  }
}
