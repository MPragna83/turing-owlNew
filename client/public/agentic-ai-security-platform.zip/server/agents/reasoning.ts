import OpenAI from "openai";
import { type DetectedVulnerability } from "./rule-engine";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface ValidatedVulnerability extends DetectedVulnerability {
  validated: boolean;
  suggestedFix: string;
  explanation: string;
}

export class ReasoningAgent {
  async validateAndGenerateFixes(vulnerabilities: DetectedVulnerability[]): Promise<ValidatedVulnerability[]> {
    const validated: ValidatedVulnerability[] = [];

    for (const vuln of vulnerabilities) {
      try {
        const result = await this.processVulnerability(vuln);
        validated.push(result);
      } catch (error) {
        console.error(`Failed to process vulnerability: ${error}`);
        validated.push({
          ...vuln,
          validated: false,
          suggestedFix: "",
          explanation: "AI analysis failed"
        });
      }
    }

    return validated;
  }

  private async processVulnerability(vuln: DetectedVulnerability): Promise<ValidatedVulnerability> {
    const prompt = `You are a security expert analyzing a potential vulnerability.

**Vulnerability Details:**
- Type: ${vuln.title}
- CWE: ${vuln.cwe}
- Severity: ${vuln.severity}
- File: ${vuln.file}
- Line: ${vuln.line}
- Description: ${vuln.description}

**Code Snippet:**
\`\`\`
${vuln.codeSnippet}
\`\`\`

Analyze this vulnerability and provide:
1. Is this a true positive? (true/false)
2. A secure code fix
3. A brief explanation of why it's vulnerable and how the fix addresses it

Respond in JSON format:
{
  "validated": boolean,
  "suggestedFix": "string",
  "explanation": "string"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a senior security engineer specializing in vulnerability analysis and remediation. Respond only with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      ...vuln,
      validated: result.validated !== false,
      suggestedFix: result.suggestedFix || this.getDefaultFix(vuln.cwe, vuln.codeSnippet),
      explanation: result.explanation || "AI-generated fix based on security best practices"
    };
  }

  private getDefaultFix(cwe: string, codeSnippet: string): string {
    const fixes: Record<string, string> = {
      "CWE-89": "const query = 'SELECT * FROM users WHERE username = $1 AND password = $2';\\nawait db.query(query, [req.body.username, req.body.password]);",
      "CWE-798": "const STRIPE_KEY = process.env.STRIPE_SECRET_KEY;\\nif (!STRIPE_KEY) throw new Error('Missing Stripe Key');\\nconst stripe = new Stripe(STRIPE_KEY);",
      "CWE-79": "import escape from 'escape-html';\\nres.send(`<h1>User Profile</h1><p>${escape(req.query.bio)}</p>`);"
    };

    return fixes[cwe] || "// Implement proper input validation and sanitization";
  }
}
