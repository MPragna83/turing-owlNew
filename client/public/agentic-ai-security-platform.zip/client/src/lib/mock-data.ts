import { Vulnerability } from "@/components/vulnerability-card";

export const MOCK_VULNERABILITIES: Vulnerability[] = [
  {
    id: "vuln-1",
    title: "SQL Injection via Login Parameters",
    severity: "critical",
    cwe: "CWE-89",
    file: "src/auth/login.ts",
    line: 42,
    description: "User input from the 'username' field is concatenated directly into a SQL query without sanitization. This allows an attacker to manipulate the query structure and bypass authentication.",
    codeSnippet: "const query = `SELECT * FROM users WHERE username = '${req.body.username}' AND password = '${req.body.password}'`;",
    suggestedFix: "const query = 'SELECT * FROM users WHERE username = $1 AND password = $2';\nawait db.query(query, [req.body.username, req.body.password]);"
  },
  {
    id: "vuln-2",
    title: "Hardcoded API Key",
    severity: "high",
    cwe: "CWE-798",
    file: "src/config/stripe.ts",
    line: 12,
    description: "A sensitive Stripe API secret key is hardcoded in the source code. This credential will be exposed if the repository is public.",
    codeSnippet: "const STRIPE_KEY = 'sk_live_51Hz...8s9d';\nconst stripe = new Stripe(STRIPE_KEY);",
    suggestedFix: "const STRIPE_KEY = process.env.STRIPE_SECRET_KEY;\nif (!STRIPE_KEY) throw new Error('Missing Stripe Key');\nconst stripe = new Stripe(STRIPE_KEY);"
  },
  {
    id: "vuln-3",
    title: "Reflected Cross-Site Scripting (XSS)",
    severity: "medium",
    cwe: "CWE-79",
    file: "src/views/profile.ts",
    line: 85,
    description: "The application reflects the 'bio' query parameter directly into the HTML response without escaping, leading to XSS.",
    codeSnippet: "res.send(`<h1>User Profile</h1><p>${req.query.bio}</p>`);",
    suggestedFix: "import escape from 'escape-html';\nres.send(`<h1>User Profile</h1><p>${escape(req.query.bio)}</p>`);"
  }
];
